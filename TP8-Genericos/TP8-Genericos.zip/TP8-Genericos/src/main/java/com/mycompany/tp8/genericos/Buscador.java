package com.mycompany.tp8.genericos;
/**
 *
 * @author lucaGomezB
 */
public class Buscador<T, K>{
    public T buscar(){
        return T;
    }
}
